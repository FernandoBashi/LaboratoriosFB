#Actividad 1 
print("Semana No.10: Ejercicio 1 ")

mes=int(input("Ingrese un número del mes 1-12: "))
if mes < 1 or mes >12: 
    print("Error: el número debe de estar entre 1 y 12 ")
    
else:
    if mes==1:
        print("Mes: Enero ")  
    elif mes==2:
        print("Mes: Febrero ")
    elif mes==3:
         print("Mes: Marzo ")
    elif mes==4:
        print("Mes: Abril ")
    elif mes==5:
        print("Mes: Mayo ")
    elif mes==6:
        print("Mes: Junio ")
    elif mes==7:
        print("Mes: Julio ")
    elif mes==8:
        print("Mes: Agosto ")
    elif mes==9:
        print("Mes: Septiembre ")
    elif mes==10:
        print("Mes: Octubre ")
    elif mes==11:
        print("Mes: Noviembre ")
    elif mes==12:
        print("Mes: Diciembre ")


#Actividad 2: 
        print("Semana No.10: Ejercicio 2 ")

        a=int(input("Ingrese su primera variable"))
        b=int(input("Ingrese su segunda variable"))
        c=int(input("Ingrese su tercera variable"))

        if a>b:
            if a>c:
                print("El número mayor es: ", a)
            elif a==c:
                print("Los número mayores son: ", a, "y", c)
            else:
                print("El número mayor es:", c)
        else:
            if a==b:
                if a>c:
                    print("Los números mayores son:", a, "y" ,b)
                else: 
                    if a==b: 
                        print("Las tres variables son iguales")
                    else: 
                        print("El número mayor es:", c)

            else:
                if b>c:
                    print("El número mayor es:", b)
                else: 
                    if b==c:
                        print("Los mayores son:", b, "y", c)
                    else:
                        print("El número mayor es:",c )








#Actividad 3 Fernando Barrientos1226323
# Solicitar al usuario que ingrese su fecha de nacimiento
dia = int(input("Introduce el día de nacimiento (1-31): "))
mes = int(input("Introduce el mes de nacimiento (1-12): "))

# Determinar el signo zodiacal basado en la fecha de nacimiento
signo_zodiacal = ""

if (mes == 3 and dia >= 21) or (mes == 4 and dia <= 19):
    signo_zodiacal = "Aries"
elif (mes == 4 and dia >= 20) or (mes == 5 and dia <= 20):
    signo_zodiacal = "Tauro"
elif (mes == 5 and dia >= 21) or (mes == 6 and dia <= 20):
    signo_zodiacal = "Géminis"
elif (mes == 6 and dia >= 21) or (mes == 7 and dia <= 22):
    signo_zodiacal = "Cáncer"
elif (mes == 7 and dia >= 23) or (mes == 8 and dia <= 22):
    signo_zodiacal = "Leo"
elif (mes == 8 and dia >= 23) or (mes == 9 and dia <= 22):
    signo_zodiacal = "Virgo"
elif (mes == 9 and dia >= 23) or (mes == 10 and dia <= 22):
    signo_zodiacal = "Libra"
elif (mes == 10 and dia >= 23) or (mes == 11 and dia <= 21):
    signo_zodiacal = "Escorpio"
elif (mes == 11 and dia >= 22) or (mes == 12 and dia <= 21):
    signo_zodiacal = "Sagitario"
elif (mes == 12 and dia >= 22) or (mes == 1 and dia <= 19):
    signo_zodiacal = "Capricornio"
elif (mes == 1 and dia >= 20) or (mes == 2 and dia <= 18):
    signo_zodiacal = "Acuario"
elif (mes == 2 and dia >= 19) or (mes == 3 and dia <= 20):
    signo_zodiacal = "Piscis"
else:
    signo_zodiacal = "Fecha no válida"

# Mostrar el signo zodiacal
if signo_zodiacal != "Fecha no válida":
    print(f"Tu signo zodiacal es: {signo_zodiacal}")
else:
    print(signo_zodiacal)



                




