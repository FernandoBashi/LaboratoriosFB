#Ejercicio 2 

# Solicitar al usuario que ingrese un número entero positivo para N
numero_N = int(input("Por favor, ingresa un número positivo para N: "))

while numero_N <= 0:
    print("El número debe ser mayor que 0.")
    numero_N = int(input("Intenta de nuevo, ingresa un número para N: "))

# Calcular la suma de la serie a
suma_serie_a = 0
contador = 1
while contador <= numero_N:
    suma_serie_a = suma_serie_a + (1 / contador)
    contador = contador + 1
print("Suma de la serie a:", suma_serie_a)

# Calcular la suma de la serie b
suma_serie_b = 0
contador = 1
while contador <= numero_N:
    suma_serie_b = suma_serie_b + (1 / (2 ** contador))
    contador = contador + 1
print("Suma de la serie b:", suma_serie_b)

# Pedir al usuario valores para x, a, y n para la serie c
x = int(input("Ingresa un valor entero para x: "))
a = int(input("Ingresa un valor entero para a: "))
n = int(input("Ingresa un valor entero para el límite n de la sumatoria: "))


suma_serie_c = 0
contador = 0
while contador <= n:
    
    numerador = 1  # Inicializar el numerador
    i = n
    while i > 0:
        numerador = numerador * i
        i = i - 1

    denominador_k = 1  # Inicializar el denominador para k
    i = contador
    while i > 0:
        denominador_k = denominador_k * i
        i = i - 1

    denominador_n_k = 1  # Inicializar el denominador para n-k
    i = n - contador
    while i > 0:
        denominador_n_k = denominador_n_k * i
        i = i - 1

    coef_binomial = numerador / (denominador_k * denominador_n_k)
    
    # Calcular el término actual de la suma de la serie c y agregarlo a la suma total
    termino_actual = coef_binomial * (x ** contador) * (a ** (n - contador))
    suma_serie_c = suma_serie_c + termino_actual
    contador = contador + 1

print("Suma de la serie c:", suma_serie_c)
